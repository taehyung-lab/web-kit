/** 필터·정렬의 공통 값 전이. 날짜는 지정한 시간대의 달력 날짜로 계산한다. */
export interface Keyword {
  readonly field: string;
  readonly value: string;
}
/** 앞뒤 공백과 같은 필드의 중복을 제거한 키워드를 추가한다. */
export function addKeyword(items: readonly Keyword[], field: string, input: string): readonly Keyword[] {
  const value = input.trim();
  if (value === '' || items.some((item) => item.field === field && item.value === value)) return items;
  return [...items, { field, value }];
}
/** 처음 누른 머리글의 정렬 방향. current는 지금 방향을 그대로 쓴다. 화면마다 정하는 값이다. */
export type SortFirst = 'asc' | 'desc' | 'current';
/** 같은 열은 방향을 바꾸고 새 열은 화면이 정한 첫 방향으로 정렬한다. */
export function nextSort(
  current: { readonly sort: string; readonly order: 'asc' | 'desc' },
  sort: string,
  first: SortFirst = 'current',
) {
  if (current.sort === sort) return { sort, order: current.order === 'asc' ? 'desc' : 'asc' } as const;
  return { sort, order: first === 'current' ? current.order : first } as const;
}
/** 검색용 전체 선택을 빈 배열로 정규화한다. 권한/등록 입력에는 사용하지 않는다. */
export function normalizeFilterSelection<T>(selected: readonly T[], options: readonly T[]): readonly T[] {
  const kept = options.filter((value) => selected.includes(value));
  return kept.length === options.length ? [] : kept;
}
/** 화면에 체크로 보이는 선택. 비어 있으면 제한 없음이라 모든 선택지가 체크로 보이고, 선택이 있으면 선택지에 있는 값만 보인다. */
export function viewFilterSelection<T>(selected: readonly T[], options: readonly T[]): readonly T[] {
  return selected.length === 0 ? options : selected.filter((value) => options.includes(value));
}
/**
 * 필터 선택의 다음 값. 아무것도 안 고른 상태는 없다: 마지막 하나를 해제하는 변경은 무시하고(현재 값을 그대로 둔다),
 * 모든 선택지를 고르면 제한 없음(빈 배열)으로 접는다.
 */
export function commitFilterSelection<T>(next: readonly T[], current: readonly T[], options: readonly T[]): readonly T[] {
  return options.some((value) => next.includes(value)) ? normalizeFilterSelection(next, options) : current;
}
export type PeriodPreset = { readonly unit: 'day' | 'month'; readonly amount: number };
/** 지정한 시각·시간대의 날짜만 읽는다. 브라우저 시간대를 암묵적으로 사용하지 않는다. */
export function calendarDate(now: Date, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  const get = (type: string) => parts.find((part) => part.type === type)!.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
/** 달력 날짜를 이동하며 월 이동은 말일로 보정한다. amount는 과거 음수/미래 양수다. */
export function shiftCalendarDate(date: string, preset: PeriodPreset): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('date must be YYYY-MM-DD');
  const [year, month, day] = date.split('-').map(Number) as [number, number, number];
  const result = new Date(Date.UTC(year, month - 1, day));
  if (result.toISOString().slice(0, 10) !== date) throw new Error('invalid calendar date');
  if (!Number.isInteger(preset.amount)) throw new Error('period amount must be an integer');
  if (preset.unit === 'day') result.setUTCDate(day + preset.amount);
  else {
    result.setUTCDate(1);
    result.setUTCMonth(month - 1 + preset.amount);
    const last = new Date(Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)).getUTCDate();
    result.setUTCDate(Math.min(day, last));
  }
  return result.toISOString().slice(0, 10);
}
