/** 폼의 검증·제출·확인·저장과 완료 처리의 수명을 소유한다. */
// 파일 책임: 등록·수정 폼의 제출 → (확인) → 저장 → 기준선/실패 반영 수명을 TanStack Form 위에서 소유한다.
import {
  evaluate,
  getBy,
  revalidateLogic,
  setBy,
  useForm,
  useSelector,
  type DeepKeys,
  type ReactFormExtendedApi,
  type StandardSchemaV1,
} from '@tanstack/react-form';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { normalizeChoiceValue, type ChoiceNode, type ChoiceValue } from '../choice-binding';
import { isRequestFailure, type FieldError } from '../failure';
import { useBlockingProgress } from '../progress';
import type { CompletionStep } from '../completion';
import { fieldIsHidden, projectConditionalFields, useConditionalFields, type ConditionalField } from './conditional';
import { followRows, rowMark } from './rows';
import { revealFormSections } from './sections';
import { useFormReferences, referenceIssues, type FormReference, type ReferenceChange } from './references';

/** 같은 폼에서 다른 검증과 요청으로 저장하는 두 번째 동작. */
export interface SecondarySave<TInput, TOutput, TResult> {
  readonly schema: StandardSchemaV1<TInput, TOutput>;
  readonly save: (values: TOutput, submitted: TInput, step: SaveStep) => Promise<TResult>;
  readonly confirm?: boolean;
  readonly acknowledge?: boolean;
  readonly onSaved?: (result: TResult, step: CompletionStep) => unknown;
}

export interface SaveFormOptions<
  TInput,
  TOutput,
  TResult = { readonly saved?: TInput } | void,
  TSecondaryOutput = TInput,
  TSecondaryResult = TResult,
> {
  /** 현재 칸의 표시 조건과 서버가 받는 빈 값을 한 곳에서 선언한다. */
  readonly conditionalFields?: (values: TInput) => readonly ConditionalField<TInput>[];
  readonly references?: readonly FormReference<TInput>[];
  /** 임시저장처럼 검증과 요청이 다른 동작. 완료 동작은 기본 저장에서 상속하지 않는다. */
  readonly secondary?: SecondarySave<TInput, TSecondaryOutput, TSecondaryResult>;
  /** 입력 → 저장 값 동기 검증. zod 4 등 Standard Schema 구현이면 되고, 비동기 검증(async refine 등)은 받지 않는다. */
  readonly schema: StandardSchemaV1<TInput, TOutput>;
  /** 편집 대상. 등록이면 기본값. id가 바뀌면 새 폼, 같은 id의 새 values는 원본 재도착이다. */
  readonly source: { readonly id: unknown; readonly values: TInput };
  /** true면 유효한 제출이 확인 대기로 가고 confirm()이 확인 대기 중인 제출 값으로 저장한다. */
  readonly confirm?: boolean;
  /**
   * 저장 작업. 서버가 저장 결과를 주면 폼 값으로 바꿔 saved로 돌려준다(없으면 제출한 S가 저장 결과다).
   * 그 밖의 결과(새 id·토큰 등)도 함께 돌려주면 onSaved가 받는다.
   * 요청 전에 화면 절차가 칸을 거절하거나, 서버가 칸 정보 없는 업무 거절로 답해 저장되지 않은 실패를 화면이 칸으로 해석하면
   * `FormRejection`을 던진다(서버 필드 오류와 같은 길로 처리된다).
   * 저장 도중 사용자에게 묻는 일(확인창)은 `step.waitForUser(물음)`으로 감싼다. 그동안 화면 전체 진행 덮개를 내린다.
   */
  readonly save: (values: TOutput, submitted: TInput, step: SaveStep) => Promise<TResult>;
  /**
   * 서버 필드 오류를 폼 경로와 표시 문구로 바꾼다. undefined면 붙이지 않는다.
   * 돌려준 경로는 제출 때 기준이다. 그 뒤 키트 줄 작업으로 줄이 옮겨졌으면 키트가 지금 위치로 옮긴다.
   */
  readonly fieldError?: (error: FieldError) => { readonly field: DeepKeys<TInput>; readonly message: string } | undefined;
  /** 오류 필드가 접힌 영역에 있으면 focus 전에 펼친다. */
  readonly reveal?: (fields: readonly string[]) => void;
  /**
   * 실패 하나가 "입력 탓"이라 입력을 고치면 사라져야 하는지 정한다(예: 로그인 아이디·비밀번호 불일치). 기본은 사라지지 않는다.
   * true를 돌려준 실패는 지금 입력이 실패한 제출 때 입력과 달라지는 순간부터 failure·unattachedFieldErrors에서 빠진다.
   * 연결 실패처럼 입력과 무관한 실패는 false로 두면 고쳐도 남는다. 입력을 제출 때 값으로 되돌리면 다시 보인다.
   */
  readonly clearFailureOnEdit?: (failure: unknown) => boolean;
  /**
   * 이 폼의 저장이 끝난 뒤 저장 함수의 결과로 한 번 실행한다(이동·알림). 늦은 결과에는 실행하지 않는다.
   * 끝날 때까지(Promise면 settle까지) 단계는 `saved`라 다시 저장할 수 없다. 실패하면 `completionFailure`가 되고
   * `complete()`가 이것만 다시 실행한다(저장 요청은 다시 나가지 않는다).
   * 콜백 내부에서 추가 await 뒤 효과를 실행할 때는 두 번째 인자의 step.isCurrent()를 확인한다.
   * 업무상 이전 결과를 폐기하고 새 제출해도 안전하면 필요한 정리를 마친 뒤 `DiscardSaveAttempt`를 반환한다.
   */
  readonly onSaved?: (result: TResult, step: CompletionStep) => unknown;
  /** true면 저장 성공 뒤 `saved`에서 멈추고, 사용자가 확인해 `complete()`를 부를 때 onSaved를 실행한다(저장 완료 확인창). */
  readonly acknowledge?: boolean;
  /**
   * 등록·수정 폼이면 그 종류. 저장하는 동안(완료 창이 없으면 완료 처리까지) 화면 전체 진행 덮개(`/ui` BlockingProgress)를 그 종류의 문구로 띄우고,
   * 저장 버튼 옆 진행 표시는 그리지 않는다. 없으면 덮개 없이 버튼 옆 진행 표시다(로그인·대화창 폼).
   */
  readonly progress?: 'create' | 'edit';
}

/** 저장 함수가 받는 진행 도구. */
export interface SaveStep {
  /** 저장 도중 사용자에게 묻는 동안(확인창) 진행 덮개를 내리고, 물음의 답을 그대로 돌려준다. */
  readonly waitForUser: <T>(question: Promise<T>) => Promise<T>;
}

export type SaveStage<TInput> =
  | { readonly kind: 'idle' }
  | { readonly kind: 'confirming'; readonly values: TInput }
  | { readonly kind: 'saving'; readonly values: TInput }
  /** 저장은 끝났고 완료 처리(onSaved)를 기다리거나 실행 중이거나 실패했다. 이 동안 제출은 잠긴다. */
  | { readonly kind: 'saved'; readonly completing: boolean };

/**
 * onSaved가 반환하는 명시적 시도 폐기 결과. 프로젝트가 세션 종료·보상 등 필요한 정리를 끝내고,
 * 새 저장 요청이 안전할 때만 반환한다. 키트는 입력을 보존하고 이전 기준선을 복원해 새 제출을 허용한다.
 * reason은 완료 위치에 안내하되 완료 재시도는 제공하지 않는다. 일반 throw는 기존 완료 재시도다.
 */
export class DiscardSaveAttempt {
  constructor(readonly reason: unknown) {}
}

/**
 * 저장 함수(save)가 칸을 거절했음을 알린다. 요청 전 화면 절차의 거절(먼저 조회가 필요한 검사·업로드 실패·확인창 취소 등)과,
 * 서버가 칸 정보 없는 업무 거절로 답해 저장되지 않은 실패를 화면이 칸으로 해석한 것(예: 같은 값이 이미 있다는 결과 코드)에 쓴다.
 * 저장이 일부라도 반영됐을 수 있는 실패에는 쓰지 않는다. save 안에서 던진다.
 * 키트는 서버 필드 오류와 같은 길로 처리한다: 제출 값과 지금 값이 같은 칸에 문구를 붙이고(줄 작업은 지금 위치로 따라감),
 * 그 칸을 가진 구역·reveal을 펼친 뒤 화면 순서 첫 오류 칸에 포커스한다. 붙지 못한 칸이 있거나 root가 있으면 폼 수준 실패(formFailure)로 남고,
 * 칸도 root도 없으면 아무것도 보이지 않는 조용한 중단이다. 저장으로 치지 않으므로 기준선·입력은 그대로다.
 */
export class FormRejection extends Error {
  constructor(
    /** 거절한 칸(폼 경로)과 칸 아래 표시 문구. */
    readonly fields: readonly { readonly field: string; readonly message: string }[] = [],
    /** 칸에 붙일 수 없는 거절을 알리는 한 줄 문구. */
    readonly root?: string,
  ) {
    super('save rejected before request');
    this.name = 'FormRejection';
  }
}

const lockedFields = new WeakMap<object, Map<string, number>>();

/**
 * 고칠 수 없는(disabled) 칸이라고 알린다. 그 칸은 오류를 숨기므로, 서버 필드 오류가 그 칸으로 대응되어도 칸에 붙은 것으로 세지 않고
 * 붙지 못한 오류(폼 한 줄)로 보낸다. 칸 부품이 마운트 동안 부르고 돌려준 함수로 푼다.
 */
export function lockField(form: object, field: string): () => void {
  const key = (form as { readonly store: object }).store;
  let locked = lockedFields.get(key);
  if (locked === undefined) {
    locked = new Map();
    lockedFields.set(key, locked);
  }
  const map = locked;
  map.set(field, (map.get(field) ?? 0) + 1);
  return () => {
    const count = (map.get(field) ?? 1) - 1;
    if (count <= 0) map.delete(field);
    else map.set(field, count);
  };
}

function isLocked(form: object, field: string): boolean {
  return lockedFields.get((form as { readonly store: object }).store)?.has(field) === true;
}

/** Standard Schema 오류 경로 → 폼 경로('a.b[0].c'). */
function issuePath(path: readonly (PropertyKey | { readonly key: PropertyKey })[] | undefined): string {
  let out = '';
  for (const segment of path ?? []) {
    const key = typeof segment === 'object' ? segment.key : segment;
    out += typeof key === 'number' ? `[${key}]` : out === '' ? String(key) : `.${String(key)}`;
  }
  return out;
}

const FILE_KINDS = new Set(['empty', 'existing', 'selected', 'removed']);

/** 칸의 빈 값: 문자열 '', 목록 [], 체크 false, 파일 칸 비어 있음, 그 밖은 undefined. */
function emptyLike(value: unknown): unknown {
  if (typeof value === 'string') return '';
  if (Array.isArray(value)) return [];
  if (typeof value === 'boolean') return false;
  if (typeof value === 'object' && value !== null && 'kind' in value && FILE_KINDS.has(String(value.kind))) return { kind: 'empty' };
  return undefined;
}

/** 폼 하나의 입력 control id. 라벨·오류·focus가 같은 id를 쓴다. */
export function formFieldControlId(formId: string, field: string): string {
  return `form-${formId}-field-${encodeURIComponent(field)}`;
}

/**
 * 저장 확인창(confirm)·저장 완료 확인창(acknowledge)을 쓰는지 타입으로 남긴 표식.
 * 값이 true면 그 단계가 있을 수 있다는 뜻이라 registry `<Form>`이 그 창의 내용(prop)을 필수로 받고, false면 받지 않는다.
 */
export interface SaveSteps {
  readonly confirm: boolean;
  readonly acknowledge: boolean;
}

/** useSaveForm이 confirm·acknowledge의 리터럴 값을 읽어 내기 위한 선언 모양. 기본·두 번째 저장 어느 쪽에서든 켜면 그 단계가 있다. */
type SaveStepDeclarations<TConfirm, TAcknowledge, TSecondaryConfirm, TSecondaryAcknowledge> = {
  readonly confirm?: TConfirm;
  readonly acknowledge?: TAcknowledge;
  readonly secondary?: { readonly confirm?: TSecondaryConfirm; readonly acknowledge?: TSecondaryAcknowledge };
};

/** 리터럴 true나 값을 미리 알 수 없는 boolean이면 "있을 수 있음"(true), 생략·false·undefined면 false. */
type StepMayExist<T> = true extends T ? true : false;

/**
 * 제출·확인·저장 수명을 소유한다. 실패는 분류하지 않고 그대로 failure로 둔다(취소만 제외).
 * 성공하면 저장 결과가 기준선이 되고, 저장 중 입력이 바뀌지 않았을 때만 입력에도 반영한다.
 * 늦은 결과는 고정한 레코드·폼 수명이 같을 때만 반영한다.
 */
export function useSaveForm<
  TInput,
  TOutput,
  TResult = { readonly saved?: TInput } | void,
  TSecondaryOutput = TInput,
  TSecondaryResult = TResult,
  TConfirm extends boolean | undefined = undefined,
  TAcknowledge extends boolean | undefined = undefined,
  TSecondaryConfirm extends boolean | undefined = undefined,
  TSecondaryAcknowledge extends boolean | undefined = undefined,
>(
  options: SaveFormOptions<TInput, TOutput, TResult, TSecondaryOutput, TSecondaryResult> &
    SaveStepDeclarations<TConfirm, TAcknowledge, TSecondaryConfirm, TSecondaryAcknowledge>,
): SaveFormEditor<
  TInput,
  TResult | TSecondaryResult,
  {
    readonly confirm: StepMayExist<TConfirm | TSecondaryConfirm>;
    readonly acknowledge: StepMayExist<TAcknowledge | TSecondaryAcknowledge>;
  }
> {
  const latest = useRef(options);
  const primaryAction = useRef(options);
  latest.current = options;
  const { source } = options;
  // reset이 확정한 기본값을 다음 useForm 갱신에도 넘긴다. 입력 상태는 TanStack Form이 소유한다.
  const defaults = useRef(source.values);
  const [baseline, setBaselineState] = useState(source.values);
  const baselineRef = useRef(source.values);
  const baselineMark = useRef(0);
  const [completionRejection, setCompletionRejection] = useState<{
    readonly failure: unknown;
    readonly clearWhenEdited?: { readonly submitted: TInput };
  }>();
  const [stage, setStageState] = useState<SaveStage<TInput>>({ kind: 'idle' });
  /** 마지막 저장 실패와, 그중 필드에 붙이지 못한 서버 필드 오류. 둘은 함께 바뀐다. */
  const [rejection, setRejection] = useState<
    | {
        readonly failure: unknown;
        readonly unattached: readonly FieldError[];
        /** 칸에 붙지 못한 화면 절차 거절(FormRejection) 칸이 있는가. */
        readonly missed: boolean;
        /** 입력을 고치면 이 실패를 지워야 할 때만 그 실패를 낸 제출의 입력이다. */
        readonly clearWhenEdited?: { readonly submitted: TInput };
      }
    | undefined
  >(undefined);
  const stageRef = useRef(stage);
  /** 지금 진행 중인 제출. 잠금이자 늦은 결과를 거르는 기준 하나다. 레코드가 바뀌면 비운다. */
  const submission = useRef<object | undefined>(undefined);
  const mounted = useRef(false);
  const identity = useRef(source.id);
  const decided = useRef(source.values);
  const pendingSave = useRef<((token: object) => Promise<void>) | undefined>(undefined);
  const completion = useRef<{ acknowledge?: boolean }>({});
  const completingAttempt = useRef<object | undefined>(undefined);
  const [saveMode, setSaveMode] = useState<'primary' | 'secondary'>('primary');
  const focusTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  /** 저장이 성공해 완료 처리를 기다리는 결과. 완료 처리를 다시 시도할 때 같은 결과를 쓴다. */
  const savedResult = useRef<{
    readonly complete: (step: CompletionStep) => unknown;
    readonly identity: unknown;
    readonly baseline: TInput;
    readonly baselineMark: number;
    readonly inputBeforeSaved: TInput;
    readonly inputAfterSaved: TInput;
    readonly submitted: TInput;
  } | undefined>(undefined);
  /** 질문 수는 제출에 귀속한다. 이전 제출의 질문은 현재 저장의 덮개를 바꾸지 않는다. */
  const [asking, setAsking] = useState<{ readonly token: object; readonly count: number } | undefined>(undefined);

  const choices = useRef(new Map<string, { token: object; nodes: readonly ChoiceNode[] }>());
  const [, updateChoices] = useState(0);
  /** 원본 값은 그대로 두고 현재 전체 선택지에 맞춘 표시·검증·제출 값을 계산한다. */
  function projectChoices(input: TInput): TInput {
    let next = input;
    for (const [name, { nodes }] of choices.current) {
      const before = getBy(next, name) as ChoiceValue;
      const after = normalizeChoiceValue(before, nodes);
      if (!evaluate(before, after)) next = setBy(next, name, after);
    }
    return next;
  }
  /** 현재 표시 조건을 읽어 검증·제출에 사용할 값을 계산한다. */
  function project(input: TInput): TInput {
    return projectConditionalFields(projectChoices(input), latest.current.conditionalFields?.(input) ?? []);
  }
  /** 숨긴 부모 아래 경로도 화면·필수·서버 오류 부착에서 제외한다. */
  function isVisible(field: string): boolean {
    return !fieldIsHidden(latest.current.conditionalFields?.(form.state.values) ?? [], field);
  }
  /** 마운트된 선택 칸의 전체 선택지만 등록하고 해제한다. */
  function registerChoice(name: string, nodes: readonly ChoiceNode[]) {
    const token = {};
    choices.current.set(name, { token, nodes });
    updateChoices((tick) => tick + 1);
    return () => {
      if (choices.current.get(name)?.token !== token) return;
      choices.current.delete(name);
      updateChoices((tick) => tick + 1);
    };
  }

  const form = useForm({
    defaultValues: defaults.current,
    onSubmitMeta: undefined as object | undefined,
    validationLogic: revalidateLogic(),
    validators: { onDynamic: { '~standard': { ...options.schema['~standard'], validate: (input: unknown) => latest.current.schema['~standard'].validate(project(input as TInput)) } } },
    onSubmit: async ({ value, meta }) => {
      if (meta === undefined || !isCurrent(meta)) return;
      // TanStack Form은 값을 바꿀 때마다 새 객체를 만든다. 제출 순간의 참조가 곧 고정된 S다(File 등은 그대로 유지).
      const submitted = project(value);
      const mark = rowMark(form);
      const action = primaryAction.current;
      const result = await action.schema['~standard'].validate(submitted);
      if (!isCurrent(meta) || result.issues !== undefined) return;
      if (rejectReferences(submitted, mark)) return;
      const run = (step: SaveStep) => action.save(result.value, submitted, step);
      if (action.confirm === true) {
        pendingSave.current = (token) => execute(token, submitted, run, mark, action.onSaved);
        setStage({ kind: 'confirming', values: submitted });
        return;
      }
      await execute(meta, submitted, run, mark, action.onSaved);
    },
    onSubmitInvalid: ({ formApi, meta }) => {
      if (meta === undefined || !isCurrent(meta)) return;
      const invalid = Object.keys(formApi.state.fieldMeta).filter(
        (name) => (formApi.getFieldMeta(name as DeepKeys<TInput>)?.errors.length ?? 0) > 0,
      );
      focusFirst(invalid);
    },
  });
  const references = useFormReferences<TInput>(
    form,
    source.id,
    options.references ?? [],
    () => submission.current === undefined && stageRef.current.kind === 'idle',
  );
  const values = useSelector(form.store, (state) => state.values);
  const conditional = useConditionalFields(form, source.id, baseline, baselineMark.current, options.conditionalFields);
  /** 필수 판정 캐시. 값이 바뀌면 새로 판정한다. */
  const requiredCache = useRef<{ values: unknown; fields: Map<string, boolean> }>({ values: undefined, fields: new Map() });

  /**
   * 칸이 필수인가: 지금 값에서 그 칸만 비워 schema로 검증했을 때 그 칸에 오류가 나면 필수다. 필수 표시의 출처는 schema 하나다.
   * 다른 칸 값에 따른 조건부 필수도 같은 검증으로 나온다(다른 칸 오류가 있어도 돌도록 쓴 규칙이어야 한다 — skill 「필수 표시」).
   */
  function isRequired(field: string): boolean {
    if (!isVisible(field)) return false;
    const current = project(form.state.values);
    if (requiredCache.current.values !== current) requiredCache.current = { values: current, fields: new Map() };
    const known = requiredCache.current.fields.get(field);
    if (known !== undefined) return known;
    const probe = setBy(current, field, emptyLike(getBy(current, field)));
    const result = latest.current.schema['~standard'].validate(probe);
    const required = !(result instanceof Promise) && (result.issues ?? []).some((issue) => issuePath(issue.path) === field);
    requiredCache.current.fields.set(field, required);
    return required;
  }

  /** 렌더 이전 이탈 판정도 최신 저장 기준선을 읽게 한다. */
  function setBaseline(next: TInput, mark = rowMark(form)) {
    baselineMark.current = mark;
    baselineRef.current = next;
    setBaselineState(next);
  }

  /** 제출이 시작된 폼 수명과 현재 대상이 같은지 비동기 경계마다 확인한다. */
  function isCurrent(token: object) {
    return mounted.current && submission.current === token && Object.is(identity.current, latest.current.source.id);
  }

  /** 렌더 전 연속 호출도 최신 단계를 보게 한다. */
  function setStage(next: SaveStage<TInput>) {
    stageRef.current = next;
    setStageState(next);
  }

  function cancelFocus() {
    clearTimeout(focusTimer.current);
    focusTimer.current = undefined;
  }

  /**
   * 거절된 제출 하나(클라이언트 검증 실패·서버 필드 오류 도착·화면 절차 거절)를 알린다: 실패한 칸을 가진 키트 구역과 화면의 접힌 영역(reveal)을 펼친 뒤,
   * disabled가 풀린 다음 작업에서 화면 순서의 첫 필드로 focus한다.
   */
  function focusFirst(fields: readonly string[]) {
    cancelFocus();
    if (fields.length === 0 || !mounted.current) return;
    const { reveal } = latest.current;
    flushSync(() => {
      revealFormSections(form, fields);
      reveal?.(fields);
    });
    focusTimer.current = setTimeout(() => {
      focusTimer.current = undefined;
      if (!mounted.current) return;
      const elements = fields
        .map((field) => document.getElementById(formFieldControlId(form.formId, field)))
        .filter((element): element is HTMLElement => element !== null)
        .sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
      elements[0]?.focus();
    }, 0);
  }

  function clearServerErrors() {
    for (const name of Object.keys(form.state.fieldMeta) as DeepKeys<TInput>[]) {
      if (form.getFieldMeta(name)?.errorMap.onServer === undefined) continue;
      form.setFieldMeta(name, (meta) => ({ ...meta, errorMap: { ...meta.errorMap, onServer: undefined } }));
    }
  }

  /**
   * 거절의 칸 오류(서버 필드 오류는 fieldError로 바꾼 것, 화면 절차 거절은 FormRejection.fields)를 같은 규칙으로 붙인다:
   * 제출 값과 지금 값이 같은 칸에만 붙이고, 배열 경로는 제출 뒤 줄 작업(mark 이후 기록)을 따라 지금 위치로 옮긴다. 그 줄이 지워졌으면 붙이지 않는다.
   * 붙인 칸, 붙이지 못한 서버 오류, 붙이지 못한 화면 절차 거절 칸이 있었는지를 돌려준다.
   */
  function attachFieldErrors(error: unknown, submitted: TInput, mark: number) {
    const attached: string[] = [];
    const unattached: FieldError[] = [];
    let missed = false;
    const entries: { readonly item?: FieldError; readonly target: { readonly field: string; readonly message: string } | undefined }[] =
      isRequestFailure(error)
        ? error.fieldErrors.map((item) => ({ item, target: latest.current.fieldError?.(item) }))
        : error instanceof FormRejection
          ? error.fields.map((target) => ({ target }))
          : [];
    for (const { item, target } of entries) {
      const now = target === undefined ? undefined : (followRows(form, target.field, mark) as DeepKeys<TInput> | undefined);
      // 화면에 없는 칸(등록되지 않은 필드)·고칠 수 없는 칸에는 붙여도 보이지 않으므로 붙이지 못한 오류로 남긴다.
      if (
        target === undefined ||
        now === undefined ||
        form.getFieldMeta(now) === undefined ||
        !isVisible(now) ||
        isLocked(form, now) ||
        !evaluate(getBy(form.state.values, now), getBy(submitted, target.field))
      ) {
        if (item === undefined) missed = true;
        else unattached.push(item);
        continue;
      }
      form.setFieldMeta(now, (meta) => ({
        ...meta,
        errorMap: { ...meta.errorMap, onServer: target.message },
      }));
      attached.push(now);
    }
    return { attached, unattached, missed };
  }

  /** 직접 값 변경도 두 저장 전에 같은 참조 무결성 검사로 거절한다. */
  function rejectReferences(submitted: TInput, mark: number): boolean {
    const issues = referenceIssues(submitted, latest.current.references ?? []);
    if (issues.length === 0) return false;
    const error = new FormRejection(issues);
    const { attached, unattached, missed } = attachFieldErrors(error, submitted, mark);
    setRejection({ failure: error, unattached, missed });
    focusFirst(attached);
    return true;
  }

  /** 현재 제출의 물음만 덮개를 내린다. 늦게 시작하거나 끝난 이전 물음은 새 제출과 섞지 않는다. */
  async function waitForUser<T>(token: object, question: Promise<T>): Promise<T> {
    if (!isCurrent(token)) return await question;
    setAsking((previous) => ({ token, count: previous?.token === token ? previous.count + 1 : 1 }));
    try {
      return await question;
    } finally {
      if (isCurrent(token)) setAsking((previous) => previous?.token === token ? { token, count: previous.count - 1 } : previous);
    }
  }

  /** 저장 한 번. 이 제출이 아직 현재 제출일 때만 결과를 반영한다. */
  async function execute<TActionResult>(
    token: object,
    submitted: TInput,
    run: (step: SaveStep) => Promise<TActionResult>,
    mark: number,
    onSaved?: (result: TActionResult, step: CompletionStep) => unknown,
  ) {
    const current = () => isCurrent(token);
    if (!current()) return;
    setStage({ kind: 'saving', values: submitted });
    let result: TActionResult;
    try {
      result = await run({ waitForUser: (question) => waitForUser(token, question) });
    } catch (error: unknown) {
      if (!current()) return;
      setStage({ kind: 'idle' });
      if (isRequestFailure(error) && error.kind === 'cancelled') return;
      const { attached, unattached, missed } = attachFieldErrors(error, submitted, mark);
      const clearWhenEdited = latest.current.clearFailureOnEdit?.(error) === true ? { submitted } : undefined;
      setRejection({ failure: error, unattached, missed, clearWhenEdited });
      focusFirst(attached);
      return;
    }
    if (!current()) return;
    const declared =
      typeof result === 'object' && result !== null && 'saved' in result ? (result as { readonly saved?: TInput }).saved : undefined;
    const saved = declared ?? submitted;
    const previous = { baseline: baselineRef.current, baselineMark: baselineMark.current, inputBeforeSaved: form.state.values };
    const replaceInput = evaluate(project(form.state.values), submitted);
    savedResult.current = {
      complete: (step) => onSaved?.(result, step), identity: identity.current, ...previous,
      inputAfterSaved: replaceInput ? saved : form.state.values, submitted,
    };
    flushSync(() => {
      if (replaceInput) replace(saved);
      else setBaseline(saved, mark);
      setStage({ kind: 'saved', completing: false });
    });
    if (completion.current.acknowledge !== true) await complete();
  }

  /**
   * 저장 성공 뒤 완료 처리(onSaved)를 한 번 실행한다. 저장 완료 확인과 완료 실패 뒤 다시 시도가 같은 길이다.
   * 저장 요청은 다시 보내지 않는다. 성공하면 idle로 돌아가고, 실패하면 saved에 남아 제출을 잠근 채 다시 시도를 기다린다.
   */
  async function complete() {
    const pending = savedResult.current;
    const now = stageRef.current;
    if (pending === undefined || now.kind !== 'saved' || now.completing) return;
    const attempt = {};
    completingAttempt.current = attempt;
    const stillHere = () => mounted.current && completingAttempt.current === attempt &&
      savedResult.current === pending && Object.is(identity.current, pending.identity);
    setStage({ kind: 'saved', completing: true });
    setCompletionRejection(undefined);
    let outcome: unknown;
    try {
      outcome = await pending.complete({ isCurrent: stillHere });
    } catch (error: unknown) {
      if (!stillHere()) return;
      completingAttempt.current = undefined;
      setStage({ kind: 'saved', completing: false });
      setCompletionRejection({ failure: error });
      return;
    }
    if (!stillHere()) return;
    completingAttempt.current = undefined;
    savedResult.current = undefined;
    if (outcome instanceof DiscardSaveAttempt) {
      // 저장 결과 정규화만 되돌린다. 저장·완료 처리 중 사용자가 고친 입력은 그대로 둔다.
      if (evaluate(form.state.values, pending.inputAfterSaved) && !evaluate(form.state.values, pending.inputBeforeSaved))
        replace(pending.inputBeforeSaved);
      setBaseline(pending.baseline, pending.baselineMark);
      const clearWhenEdited = latest.current.clearFailureOnEdit?.(outcome.reason) === true ? { submitted: pending.submitted } : undefined;
      setCompletionRejection({ failure: outcome.reason, clearWhenEdited });
    }
    setStage({ kind: 'idle' });
  }

  /** 검증 → 확인 대기 또는 저장. 진행 중·확인 대기 중에는 다시 들어가지 않는다. */
  async function submit() {
    if (references.isPending() || submission.current !== undefined || stageRef.current.kind !== 'idle') return;
    const token = {};
    submission.current = token;
    pendingSave.current = undefined;
    completion.current = { acknowledge: latest.current.acknowledge };
    primaryAction.current = latest.current;
    setSaveMode('primary');
    cancelFocus();
    clearServerErrors();
    setRejection(undefined);
    setCompletionRejection(undefined);
    try {
      conditional.reconcile();
      if (rejectReferences(projectConditionalFields(form.state.values, latest.current.conditionalFields?.(form.state.values) ?? []), rowMark(form))) return;
      // 숨긴 칸의 빈 값을 schema가 거절하면 설정 오류를 조용히 버리지 않고 폼 한 줄로 알린다.
      const projected = project(form.state.values);
      const checked = latest.current.conditionalFields === undefined ? undefined : await latest.current.schema['~standard'].validate(projected);
      if (!isCurrent(token)) return;
      if (checked?.issues?.some((issue) => !isVisible(issuePath(issue.path)))) {
        const error = new FormRejection(checked.issues.map((issue) => ({ field: issuePath(issue.path), message: issue.message })), checked.issues[0]?.message);
        const { attached, unattached, missed } = attachFieldErrors(error, projected, rowMark(form));
        setRejection({ failure: error, unattached, missed });
        focusFirst(attached);
        return;
      }
      // 이미 떠 있는 blur 오류가 있으면 TanStack 제출은 전체 검증 없이 멈춘다. 필드 단위 blur 검증과 폼 검증을
      // 먼저 다시 돌려, 고친 값의 오류는 지우고 남은 오류는 모두 보인다.
      await form.validateAllFields('blur');
      if (!isCurrent(token)) return;
      await form.validate('blur');
      if (!isCurrent(token)) return;
      await form.validate('submit');
      if (!isCurrent(token)) return;
      await form.handleSubmit(token);
    } finally {
      release(token);
    }
  }

  /** 두 번째 검증만 실행하고 같은 잠금·저장·기준선 갱신 경로로 보낸다. */
  async function submitSecondary() {
    const action = latest.current.secondary;
    if (action === undefined || references.isPending() || submission.current !== undefined || stageRef.current.kind !== 'idle') return;
    const token = {};
    submission.current = token;
    setSaveMode('secondary');
    completion.current = { acknowledge: action.acknowledge };
    cancelFocus();
    clearServerErrors();
    setRejection(undefined);
    setCompletionRejection(undefined);
    conditional.reconcile();
    const submitted = project(form.state.values);
    const mark = rowMark(form);
    try {
      if (rejectReferences(projectConditionalFields(form.state.values, latest.current.conditionalFields?.(form.state.values) ?? []), mark)) return;
      const result = await action.schema['~standard'].validate(submitted);
      if (!isCurrent(token)) return;
      if (result.issues !== undefined) {
        const fields = result.issues.filter((issue) => (issue.path?.length ?? 0) > 0);
        const root = result.issues.filter((issue) => (issue.path?.length ?? 0) === 0).map((issue) => issue.message);
        const error = new FormRejection(
          fields.map((issue) => ({ field: issuePath(issue.path), message: issue.message })),
          root[0],
        );
        const { attached, unattached, missed } = attachFieldErrors(error, submitted, mark);
        setRejection({ failure: error, unattached, missed });
        focusFirst(attached);
        return;
      }
      if (rejectReferences(submitted, mark)) return;
      // 두 번째 schema에서 얻은 값과 저장 함수를 확인창을 여는 시점에 고정한다.
      const run = (step: SaveStep) => action.save(result.value, submitted, step);
      if (action.confirm === true) {
        pendingSave.current = (token) => execute(token, submitted, run, mark, action.onSaved);
        setStage({ kind: 'confirming', values: submitted });
      } else {
        await execute(token, submitted, run, mark, action.onSaved);
      }
    } finally {
      release(token);
    }
  }

  /** 확인창에 보여 준 S로 저장한다. */
  async function confirm() {
    const requested = stageRef.current;
    const run = pendingSave.current;
    if (submission.current !== undefined || requested.kind !== 'confirming' || run === undefined) return;
    const token = {};
    submission.current = token;
    pendingSave.current = undefined;
    try {
      await run(token);
    } finally {
      release(token);
    }
  }

  /** 자기 제출일 때만 잠금을 푼다. 이전 제출의 늦은 종료는 새 제출을 건드리지 않는다. */
  function release(token: object) {
    if (submission.current === token) submission.current = undefined;
  }

  /** 실행 전 확인만 취소한다. */
  function cancel() {
    if (submission.current !== undefined || stageRef.current.kind !== 'confirming') return;
    pendingSave.current = undefined;
    setStage({ kind: 'idle' });
  }

  // 레코드가 바뀌면 진행 중 결과를 버리고 새 원본으로 시작한다. 같은 레코드면 원본 재도착 규칙을 따른다.
  useLayoutEffect(() => {
    if (!Object.is(identity.current, source.id)) {
      identity.current = source.id;
      decided.current = source.values;
      submission.current = undefined;
      pendingSave.current = undefined;
      savedResult.current = undefined;
      cancelFocus();
      setStage({ kind: 'idle' });
      setRejection(undefined);
      setCompletionRejection(undefined);
      replace(source.values);
      return;
    }
    if (stage.kind !== 'idle' || evaluate(decided.current, source.values)) return;
    decided.current = source.values;
    if (evaluate(project(form.state.values), projectChoices(baseline))) replace(source.values);
  });

  function replace(next: TInput) {
    defaults.current = next;
    form.reset(next);
    setBaseline(next);
  }

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      cancelFocus();
    };
  }, []);

  // 등록·수정 폼의 저장(완료 창이 없으면 완료 처리까지)을 진행 덮개에 알린다. 사용자에게 묻는 동안은 내린다.
  const waitingForUser = asking?.token === submission.current && (asking?.count ?? 0) > 0;
  const blocking =
    (stage.kind === 'saving' && !waitingForUser) || (stage.kind === 'saved' && stage.completing && completion.current.acknowledge !== true);
  useBlockingProgress(options.progress ?? 'create', options.progress !== undefined && blocking);

  // 입력을 고치면 지우기로 한 실패는 지금 입력이 제출 때 입력과 달라진 동안 보이지 않는다.
  const visibleRejection =
    rejection?.clearWhenEdited !== undefined && !evaluate(values, rejection.clearWhenEdited.submitted) ? undefined : rejection;
  const completionFailure =
    completionRejection?.clearWhenEdited !== undefined && !evaluate(values, completionRejection.clearWhenEdited.submitted)
      ? undefined : completionRejection?.failure;

  const failure = visibleRejection?.failure;
  const unattached = visibleRejection?.unattached ?? [];
  // 서버가 지목한 필드 오류가 모두 칸에 붙은 검증 실패와, 칸이 모두 붙고 root가 없는 화면 절차 거절(칸이 없으면 조용한 중단)은
  // 칸이 이미 알린다. 그 밖의 실패만 폼 수준에 남는다.
  const allAttached =
    (isRequestFailure(failure) && failure.kind === 'validation' && failure.fieldErrors.length > 0 && unattached.length === 0) ||
    (failure instanceof FormRejection && failure.root === undefined && visibleRejection?.missed !== true);

  return {
    form,
    referenceChange: references.change,
    referenceFailure: references.failure,
    identity: source.id,
    acknowledge: completion.current.acknowledge === true,
    saveMode,
    submitSecondary: options.secondary === undefined ? undefined : submitSecondary,
    progress: options.progress,
    stage,
    /** 저장 실패 원본. 표시 방식은 화면이 kind로 정한다. */
    failure,
    /** 폼 수준(한 줄)에 보일 실패. 모든 필드 오류가 칸에 붙었으면 undefined다. */
    formFailure: allAttached ? undefined : failure,
    /** 저장은 성공했지만 완료 후 이동·알림이 실패했다. 재저장 실패와 구분한다. */
    completionFailure,
    /** 필드에 붙이지 못한 서버 필드 오류(저장 중 바뀐 필드·폼 경로로 바꾸지 못한 것). 폼 수준 표시의 근거다. */
    unattachedFieldErrors: unattached,
    /** 기준선(마지막으로 확정된 원본 또는 저장 결과). 차이로 요청을 만드는 화면이 읽는다. 바꾸지 않는다. */
    baseline: projectChoices(baseline),
    registerChoice,
    /** 현재 입력이 기준선과 다른가. */
    isDirty: !evaluate(project(values), projectChoices(baseline)),
    isSaving: stage.kind === 'saving',
    /** 같은 이벤트 안의 이동도 현재 입력과 기준선으로 판정한다. */
    getState: () => {
      conditional.reconcile();
      return {
        stage: stageRef.current.kind,
        isDirty: !evaluate(project(form.state.values), projectChoices(baselineRef.current)),
        isSaving: stageRef.current.kind === 'saving',
      };
    },
    fieldId: (field: DeepKeys<TInput>) => formFieldControlId(form.formId, field),
    isVisible,
    isRequired: (field: DeepKeys<TInput>) => isRequired(field),
    submit,
    confirm,
    cancel,
    complete,
  };
}

/** useSaveForm이 돌려주는 편집 상태. `registry form`의 `<Form editor>`가 이 모양을 읽는다. */
export interface SaveFormEditor<TInput, TResult = unknown, TSteps extends SaveSteps = SaveSteps> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- 검증기 타입 인자 12개는 화면이 알 필요가 없다.
  readonly form: ReactFormExtendedApi<TInput, any, any, any, any, any, any, any, any, any, any, any>;
  /** 편집 대상 식별(source.id). 바뀌면 진행 중이던 이탈 허가가 무효가 된다. */
  readonly identity: unknown;
  /** 저장 성공 뒤 사용자 확인을 기다리는가(acknowledge 값). */
  readonly acknowledge: boolean;
  /** 진행 덮개를 쓰는 등록·수정 폼의 종류(progress 값). 있으면 저장 버튼 옆 진행 표시·저장 중 확인창을 그리지 않는다. */
  readonly progress: 'create' | 'edit' | undefined;
  readonly stage: SaveStage<TInput>;
  readonly failure: unknown;
  readonly formFailure: unknown;
  readonly completionFailure: unknown;
  readonly unattachedFieldErrors: readonly FieldError[];
  readonly baseline: TInput;
  /** 복사형 Choice가 준비된 전체 선택지를 연결한다. 원본 값은 유지한다. */
  readonly registerChoice: (name: string, nodes: readonly ChoiceNode[]) => () => void;
  readonly isDirty: boolean;
  readonly isSaving: boolean;
  readonly getState: () => { readonly stage: SaveStage<TInput>['kind']; readonly isDirty: boolean; readonly isSaving: boolean };
  readonly fieldId: (field: DeepKeys<TInput>) => string;
  /** 조건 선언을 읽은 현재 표시 여부. 숨긴 부모 아래 경로도 false다. */
  readonly isVisible: (field: DeepKeys<TInput>) => boolean;
  /** 필수 표시(별표·aria-required): 그 칸만 비운 지금 값을 schema가 거부하는가. */
  readonly isRequired: (field: DeepKeys<TInput>) => boolean;
  readonly submit: () => Promise<void>;
  readonly referenceChange?: ReferenceChange;
  readonly referenceFailure?: string;
  readonly submitSecondary?: () => Promise<void>;
  readonly saveMode?: 'primary' | 'secondary';
  readonly confirm: () => Promise<void>;
  readonly cancel: () => void;
  readonly complete: () => Promise<void>;
  /** 타입 위치만 쓰는 표식. 저장 결과 타입을 부품까지 잇는다. */
  readonly __result?: TResult;
  /** 타입 위치만 쓰는 표식. 저장 확인창·완료 확인창이 있을 수 있는지를 registry `<Form>`의 필수 prop까지 잇는다. 실행 값은 없다. */
  readonly __steps?: TSteps;
}
